import h5py
import numpy as np
import torch
import torch.nn as nn
import scipy.io as scio
import time
import matplotlib.pyplot as plt


start_time = time.time()
device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"Using device: {device}")


def load_mat_auto(path, var_name):
    try:
        mat = scio.loadmat(path)
        data = mat[var_name]
    except NotImplementedError:
        with h5py.File(path, "r") as f:
            data = np.array(f[var_name][()]).T
    return data

def format_tensor(x):
    # -> [B,1,D,H,W]
    if x.ndim == 3:
        x = x[None, None]
    elif x.ndim == 4:
        x = x[:, None]
    return torch.tensor(x, dtype=torch.float32)


path = './noisy_data.mat'
noisy = load_mat_auto(path, 'data')
noisy = format_tensor(noisy)


noisy = noisy.to(device)

print("Input shape:", noisy.shape)


def estimate_sigma_3d(x, num_slices=10):
    b = x.size(0)
    sigma2_all = 0.0

    unfold = nn.Unfold(kernel_size=9)

    for i in range(b):
        vol = x[i, 0]  # [D,H,W]
        D = vol.shape[0]

        idxs = torch.linspace(0, D - 1, num_slices).long()

        sigma2_slice = 0.0

        for d in idxs:
            sl = vol[d].unsqueeze(0).unsqueeze(0)  # [1,1,H,W]

            patches = unfold(sl).squeeze(0)
            cov = torch.cov(patches)

            eigvals = torch.linalg.eigvalsh(cov)
            eigvals = torch.flip(eigvals, dims=[0])

            k = eigvals.shape[0] // 10
            sigma2_slice += eigvals[-k:].mean()

        sigma2_all += sigma2_slice / num_slices

    sigma2_all = sigma2_all / b
    return torch.sqrt(torch.clamp(sigma2_all, min=1e-8))

sigma = estimate_sigma_3d(noisy).item()
print(f"Sigma: {sigma:.6f}")



class SR3D(nn.Module):
    def __init__(self, ch):
        super().__init__()
        self.low = nn.Conv3d(ch, ch, 5, padding=2)
        self.high = nn.Conv3d(ch, ch, 3, padding=1)

        self.gate = nn.Sequential(
            nn.Conv3d(ch, ch, 1),
            nn.Sigmoid()
        )

        self.recon = nn.Conv3d(ch, ch, 3, padding=1)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        low = self.low(x)
        high = self.high(x)

        feat = low + high
        feat = feat * self.gate(feat)

        out = self.recon(self.relu(feat))
        return out + x


class RAM3D(nn.Module):
    def __init__(self):
        super().__init__()

        self.e1 = nn.Conv3d(1, 32, 3, padding=1)
        self.e2 = nn.Conv3d(1, 32, 5, padding=2)
        self.f1 = nn.Conv3d(64, 64, 1)

        self.pool = nn.MaxPool3d(2)

        self.e3 = nn.Conv3d(64, 128, 3, padding=1)

        self.ssr = SR3D(128)

        self.up1 = nn.Upsample(scale_factor=2, mode='trilinear', align_corners=False)
        self.d1 = nn.Conv3d(128, 64, 3, padding=1)

        self.up2 = nn.Upsample(scale_factor=2, mode='trilinear', align_corners=False)
        self.d2 = nn.Conv3d(64, 32, 3, padding=1)

        self.out = nn.Conv3d(32, 1, 3, padding=1)

        self.act = nn.ReLU()

    def forward(self, x):
        input_size = x.shape[2:]
    
        x1 = torch.cat([
            self.act(self.e1(x)),
            self.act(self.e2(x))
        ], dim=1)
    
        x1 = self.act(self.f1(x1))
    
        x = self.pool(x1)
        x = self.act(self.e3(x))
    
        x = self.pool(x)
        x = self.ssr(x)
    
        x = self.up1(x)
        x = self.act(self.d1(x))
    
        x = self.up2(x)
        x = self.act(self.d2(x))
    
        x = self.out(x)
    
        # 保证输出与输入尺寸一致
        x = nn.functional.interpolate(
            x,
            size=input_size,
            mode='trilinear',
            align_corners=False
        )
    
        return x


def mc_sure(model, y, sigma, eps=1e-4):
    f = model(y)

    noise = torch.randn_like(y)
    f_eps = model(y + eps * noise)

    div = ((f_eps - f) * noise).sum() / (eps * noise.numel())

    mse = ((f - y) ** 2).mean()

    return mse - sigma**2 + 2 * sigma**2 * div


model = RAM3D().to(device)
opt = torch.optim.Adam(model.parameters(), lr=1e-3)

print("Params:", sum(p.numel() for p in model.parameters()))

for epoch in range(3000):
    opt.zero_grad()
    loss = mc_sure(model, noisy, sigma)
    loss.backward()
    opt.step()

    print(f"Epoch {epoch+1:4d} | Loss {loss.item():.6f}")


model.eval()
with torch.no_grad():
    out = model(noisy).cpu().numpy()



noisy_np = noisy[0,0].cpu().numpy()
denoised_np =out[0,0]
residual = noisy_np - denoised_np



z = noisy_np.shape[0] // 2

vmin, vmax = -1, 1

plt.figure(figsize=(12,4))

plt.subplot(1,3,1)
plt.imshow(noisy_np[z], cmap='seismic', vmin=vmin, vmax=vmax)
plt.title("Noisy slice")

plt.subplot(1,3,2)
plt.imshow(denoised_np[z], cmap='seismic', vmin=vmin, vmax=vmax)
plt.title("Denoised slice")

plt.subplot(1,3,3)
plt.imshow(residual[z], cmap='seismic', vmin=vmin, vmax=vmax)
plt.title("Residual slice")

plt.tight_layout()
plt.show()

print(f"Time: {time.time()-start_time:.2f}s")




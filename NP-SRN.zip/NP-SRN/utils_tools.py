import torch.nn as nn
import torch

def noise_estimate(x):
    """
    Noise level estimation based on PCA of local patch covariance.

    This implementation is inspired by:
    Peng, J., Li, Y., Liao, Z., Wang, X., & Yang, X. (2024).
    Seismic data strong noise attenuation based on diffusion model and PCA.
    IEEE Transactions on Geoscience and Remote Sensing, 62, 1–11.

    The method estimates noise variance using the smallest eigenvalues
    of patch covariance matrices.
    """
    b = x.size(0)
    unfold = nn.Unfold(kernel_size=9)
    sigma2 = 0.0

    for i in range(b):
        patches = unfold(x[i:i+1]).squeeze(0)
        cov = torch.cov(patches)
        eigvals = torch.linalg.eigvalsh(cov)
        eigvals = torch.flip(eigvals, dims=[0])

        k = eigvals.shape[0] // 10
        sigma2 += eigvals[-k:].mean()

    sigma2 = sigma2 / b
    return torch.sqrt(torch.clamp(sigma2, min=1e-8))


# -*- coding: utf-8 -*-
import h5py
import numpy as np
import torch
import torch.nn as nn
import scipy.io as scio
import time
import matplotlib.pyplot as plt
from utils_tools import noise_estimate

start_time = time.time()
device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"Using device: {device}")


def load_mat_auto(path, var_name):
    try:
        mat = scio.loadmat(path)
        data = mat[var_name]
    except NotImplementedError:
        with h5py.File(path, "r") as f:
            data = np.array(f[var_name][()]).T
    return data

def format_tensor(x):
    if x.ndim == 2:
        x = x[None, None]
    elif x.ndim == 3:
        x = x[:, None]
    return torch.tensor(x, dtype=torch.float32)

# load data
path = './data/noisy_data.mat'
noisy = load_mat_auto(path, 'noisy_data')
noisy = format_tensor(noisy)

# norm
data_min = noisy.min().item()
data_max = noisy.max().item()

noisy = 2 * (noisy - data_min) / (data_max - data_min) - 1
noisy = noisy.to(device)

print("Input shape:", noisy.shape)


sigma = noise_estimate(noisy).item()
print(f"Sigma: {sigma:.6f}")


# SR block
class SR(nn.Module):
    def __init__(self, ch):
        super().__init__()
        self.low = nn.Conv2d(ch, ch, 5, padding=2)
        self.high = nn.Conv2d(ch, ch, 3, padding=1)

        self.gate = nn.Sequential(
            nn.Conv2d(ch, ch, 1),
            nn.Sigmoid()
        )

        self.recon = nn.Conv2d(ch, ch, 3, padding=1)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        low = self.low(x)
        high = self.high(x)

        feat = low + high
        feat = feat * self.gate(feat)

        out = self.recon(self.relu(feat))
        return out + x

# network
class SRN(nn.Module):
    def __init__(self):
        super().__init__()

        self.e1 = nn.Conv2d(1, 32, 3, padding=1)
        self.e2 = nn.Conv2d(1, 32, 5, padding=2)
        self.f1 = nn.Conv2d(64, 64, 1)

        self.pool = nn.MaxPool2d(2)

        self.e3 = nn.Conv2d(64, 128, 3, padding=1)

        self.ssr = SR(128)

        self.up1 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False)
        self.d1 = nn.Conv2d(128, 64, 3, padding=1)

        self.up2 = nn.Upsample(scale_factor=2, mode='bilinear', align_corners=False)
        self.d2 = nn.Conv2d(64, 32, 3, padding=1)

        self.out = nn.Conv2d(32, 1, 3, padding=1)

        self.act = nn.ReLU()

    def forward(self, x):
        x1 = torch.cat([self.act(self.e1(x)), self.act(self.e2(x))], dim=1)
        x1 = self.act(self.f1(x1))

        x = self.pool(x1)

        x = self.act(self.e3(x))
        x = self.pool(x)

        x = self.ssr(x)

        x = self.up1(x)
        x = self.act(self.d1(x))

        x = self.up2(x)
        x = self.act(self.d2(x))

        return self.out(x)


# MC-SURE loss
def mc_sure(model, y, sigma, eps=1e-4):
    f = model(y)

    noise = torch.randn_like(y)
    f_eps = model(y + eps * noise)
    div = ((f_eps - f) * noise).sum() / (eps * noise.numel())
    mse = ((f - y) ** 2).mean()
    return mse - sigma**2 + 2 * sigma**2 * div


# train
model = SRN().to(device)
opt = torch.optim.Adam(model.parameters(), lr=1e-3)
print(sum([param.nelement() for param in model.parameters()]))
for epoch in range(3000):
    opt.zero_grad()
    loss = mc_sure(model, noisy, sigma)
    loss.backward()
    opt.step()

    print(f"Epoch {epoch+1:3d} | Loss {loss.item():.6f}")


# inference
model.eval()
with torch.no_grad():
    out = model(noisy).cpu().numpy()

# denorm
def denorm(x):
    return (x + 1)/2 * (data_max - data_min) + data_min

noisy_np = denorm(noisy[0,0].cpu().numpy())
denoised_np = denorm(out[0,0])
residual = noisy_np - denoised_np

# ======================================================
# 可视化
# ======================================================
vmin, vmax = -10, 10

plt.figure(figsize=(12,4))

plt.subplot(1,3,1)
plt.imshow(noisy_np, cmap='seismic', vmin=vmin, vmax=vmax)
plt.title("Noisy")

plt.subplot(1,3,2)
plt.imshow(denoised_np, cmap='seismic', vmin=vmin, vmax=vmax)
plt.title("Denoised")

plt.subplot(1,3,3)
plt.imshow(residual, cmap='seismic', vmin=vmin, vmax=vmax)
plt.title("Residual")

plt.tight_layout()
plt.show()

# save
# scio.savemat(
#     r'./data/proposed1.mat',
#     {'data': denoised_np}
# )

# print(f"Time: {time.time()-start_time:.2f}s")